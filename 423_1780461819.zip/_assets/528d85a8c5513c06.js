(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96819],{

/***/ 723483:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var BBc;__c.A_=function({loop:a=!1,MS:b,TT:c,pg:d,rendererSettings:e,En:f}){const g=yBc(null),h=yBc(void 0);zBc(()=>{const k=__c.y(g.current),l=__c.Jc.jc&&!d,m=l?void 0:[c,c];h.current=ABc().loadAnimation({autoplay:l,container:k,initialSegment:m,loop:a??!1,path:b,renderer:"svg",rendererSettings:e});a||h.current.addEventListener("complete",()=>{f?.()});return()=>{h.current&&h.current.destroy()}},[]);return BBc("div",{className:"sH8e1w",ref:g})};BBc=__webpack_require__(296713).jsx;var CBc=__webpack_require__,DBc=CBc(802496),ABc=CBc.n_x(DBc);var EBc=__webpack_require__(978109),zBc=EBc.useEffect,yBc=EBc.useRef;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/528d85a8c5513c06.js.map