(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[44242],{

/***/ 824693:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var GQc;
GQc=class{process(a){try{for(const b of a){const c=`${b.name}-${b.spanContext().spanId}`;this.performance.mark(`${c}-start`,{startTime:Math.max(b.startTime,0)});this.performance.mark(`${c}-end`,{startTime:b.endTime});const d=b.aborted,e=b.status==="error",f=b.Uy==="event";let g="";__c.ML(b)?g="UOP: ":f&&(g="Event: ");e?g=`[Error] ${g}`:d&&(g=`[Aborted] ${g}`);this.performance.measure(`${g}${b.name}`,{start:Math.max(b.startTime,0),end:b.Uy==="event"?(b.endTime??0)+.5:b.endTime})}}catch(b){this.J.Mb(b,{Te:`Failed to export the span buffer from ${GQc.name}`,
extra:new Map(__c.RL(a))})}finally{this.xo?.process(a)}}nw(a){this.xo?.nw(a)}async flush(){return this.xo?.flush()}constructor(a,b,c=self.performance){this.J=a;this.xo=b;this.performance=c}};__c.HQc={};__c.HQc.z_a=GQc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/03de436cd23212dc.js.map