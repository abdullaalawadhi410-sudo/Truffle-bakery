(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[57702],{

/***/ 487889:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var $vc,Yvc,Zvc,Xvc;
__c.iZ=function(a){const b=({epb:c=!1,children:d})=>{const e=Tvc(),f=Uvc(null);Vvc(()=>Wvc(()=>{const {width:g,height:h,top:k=0,left:l=0}=a(),m=f.current;m&&(m.setAttribute("width",g.toString()),m.setAttribute("height",h.toString()),m.setAttribute("x",l.toString()),m.setAttribute("y",k.toString()))}),[]);return Xvc(Yvc,{children:[!c&&Zvc("clipPath",{id:e,children:Zvc("rect",{ref:f})}),Zvc("g",{clipPath:c?void 0:`url(#${e})`,children:d})]})};b.displayName=a.name!=null?`ClippingContainer(${a.name})`:"ClippingContainer";
return b};$vc=__webpack_require__(296713);Yvc=$vc.Fragment;Zvc=$vc.jsx;Xvc=$vc.jsxs;var awc=__webpack_require__(978109),Vvc=awc.useEffect,Tvc=awc.useId,Uvc=awc.useRef;var Wvc=__webpack_require__(186901).fm;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/e5d57e2cbb20976a.js.map