(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97006],{

/***/ 165845:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.fWb={config:{language:"vi-VN",Mg:{yMMMd:"d MMM, yyyy",yMd:"d/M/yyyy",yMMM:"MMM, yyyy"},fh:"thg 1;thg 2;thg 3;thg 4;thg 5;thg 6;thg 7;thg 8;thg 9;thg 10;thg 11;thg 12".split(";"),gh:"th\u00e1ng 1;th\u00e1ng 2;th\u00e1ng 3;th\u00e1ng 4;th\u00e1ng 5;th\u00e1ng 6;th\u00e1ng 7;th\u00e1ng 8;th\u00e1ng 9;th\u00e1ng 10;th\u00e1ng 11;th\u00e1ng 12".split(";"),Zh:[{pattern:"dd *[./\\s-] *mm *[./\\s-] *yy",ya:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",ya:"yMd"},{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",
ya:"yMd"},{pattern:"dd *[./\\s-] *mm",ya:"yMd"},{pattern:"mmm, yyyy",ya:"yMMM"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/45ba22e0abf05a80.js.map