(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87444],{

/***/ 432371:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(829258);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var eRc=function(a,b){a.WD.sW();return __c.QQc(b,c=>a.WD.AL(c))},fRc=function(a,b){const c=b.TELEMETRY?.queuedOnSpanEndListener;b.TELEMETRY?.queuedOnSpanStartListener?.forEach(d=>a.KQa.push(d));c?.forEach(d=>a.JQa.push(d))},gRc=__webpack_require__(929846)._;var hRc;
hRc=class{nw(a){try{const b=eRc(this,[a]);for(const c of this.KQa)c(b)}catch(b){this.J.Mb(b)}this.xo.nw(a)}process(a){try{const b=eRc(this,a);for(const c of this.JQa)c(b)}catch(b){this.J.Mb(b)}this.xo.process(a)}async flush(){const a=gRc()();try{a.r(await a.s(this.xo.flush()))}finally{a.s()}}constructor(a,b,c=globalThis,d=new __c.brc){this.J=a;this.xo=b;this.global=c;this.WD=d;this.KQa=[];this.JQa=[];try{c.TELEMETRY={...c.TELEMETRY,addOnSpanStartListener:e=>{this.KQa.push(e)},addOnSpanEndListener:e=>{this.JQa.push(e)}},
fRc(this,c)}catch(e){a.Mb(e)}}};__c.dRc={};__c.dRc.ewb=hRc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/0d2229c3be11bc92.js.map