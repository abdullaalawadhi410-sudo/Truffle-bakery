(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[41498],{

/***/ 697521:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(135194);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Jkd={Ue:"live_audience_panel_toggled",Wf(a){return __c.Rs({presenting_context:a.Fe==null?void 0:__c.NK(a.Fe),session_id:a.sessionId,source:a.source,action:a.action,design_id:a.xg,doctype_id:a.Vo,category_id:a.fd})}},Kkd=__webpack_require__(186901),Lkd=Kkd.sH,Mkd=Kkd.XI;var Nkd;
Nkd=class{static G(a){__c.M(a,{gs:Lkd.ref,open:Mkd.bound,close:Mkd.bound,toggle:Mkd.bound})}get Be(){return this.gs}open(){this.gs||(this.gs=!0,this.ma.track(Jkd,{sessionId:this.mp.state.session?.id,source:"fullscreen_mode",action:"show",xg:""}))}close(){this.gs&&(this.gs=!1,this.ma.track(Jkd,{sessionId:this.mp.state.session?.id,source:"fullscreen_mode",action:"hide",xg:""}))}toggle(){this.gs=!this.gs;this.ma.track(Jkd,{sessionId:this.mp.state.session?.id,source:"fullscreen_mode",action:this.gs?"show":
"hide",xg:""})}constructor(a,b){this.mp=a;this.ma=b;this.gs=(Nkd.G(this),void 0);this.gs=!!this.mp.state.session}};__c.l3a={};__c.l3a.fvb=Nkd;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/be0f2939759193d8.js.map