(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97337],{

/***/ 241445:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(930574);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Nrc=__webpack_require__(296713).jsx;var Orc=__webpack_require__,Prc=Orc(802496),Qrc=Orc.n_x(Prc);var Rrc=__webpack_require__(978109).Component;var Src=__webpack_require__(186901),Trc=Src.m3,Urc=Src.mJ;var Vrc=__webpack_require__(621369)._;var Wrc,Xrc,Yrc=class extends Rrc{componentDidMount(){__c.nc(this,[Urc(()=>[this.props.animationData,this.props.fc],()=>{const a=this.props.animationData,b=this.props.fc,c=this.props.gH;a&&this.loadAnimation(a,b,c)},{fireImmediately:!0,equals:Trc.shallow}),Urc(()=>this.props.gH,a=>{this.Sp&&this.Sp.goToAndStop(a*1E3)},{fireImmediately:!0})])}componentWillUnmount(){this.Sp?.destroy()}render(){const a=this.props.Ca,{ariaHidden:b,ariaLabel:c}=__c.H$b(a);return Nrc("div",{className:"_8i6R0w",ref:this.x7,
role:a?"img":void 0,"aria-label":c,"aria-hidden":b})}loadAnimation(a,b,c){const d=this.x7.current;d&&(a=JSON.parse(JSON.stringify(a)),__c.Lrc(a,b),this.Sp&&this.Sp.destroy(),this.Sp=Qrc().loadAnimation({autoplay:!1,animationData:a,container:d,renderer:"svg"}),b=d.getElementsByTagName("svg")[0])&&(b.style.transform==="translate3d(0px, 0px, 0px)"&&(b.style.transform=""),this.Sp.goToAndStop(c*1E3))}constructor(...a){super(...a);this.x7=__c.bz()}};({c:[Xrc,Wrc]}=Vrc(Yrc,[],[__c.wc],Rrc));Wrc();
__c.Y$b={};__c.Y$b.Mxb=Xrc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/56b8d24971a481fb.js.map