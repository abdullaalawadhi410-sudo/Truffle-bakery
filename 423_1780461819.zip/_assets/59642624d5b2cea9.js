(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87001],{

/***/ 297724:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(162160);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var wBc;wBc=function(a,b){a=__c.Fvc(a);return{fixed:a.fixed*b,Ci:a.Ci*b}};__c.z_=class extends __c.Gvc{So(a,b){const c=this.fa.rect,d=this.fa.velocity,e=a.random(),f=a.random();if(d)switch(d.type){case "relative":b.velocity=b.velocity.add(__c.ZW(d.x.min,d.x.max,e),__c.ZW(d.y.min,d.y.max,f));break;case "random":b.velocity=b.velocity.add(__c.XY(d.x,a),__c.XY(d.y,a))}return{x:__c.$Y(c.x,wBc(c.width,e)),y:__c.$Y(c.y,wBc(c.height,f)),offset:void 0}}constructor(a){super(a);this.fa=a}};
__c.xBc=class{So(a){return{rect:this.fa.rect&&__c.Dvc(this.fa.rect,a)}}Iy(a,b,c,d){c=this.fa.image;c instanceof HTMLImageElement&&!c.complete||(a=a.Da,d=d.rect,__c.Evc(a,b),a.globalAlpha*=b.color.a,d!=null?a.drawImage(c,d.x,d.y,d.width,d.height):a.drawImage(c,c.width*-.5,c.height*-.5),b.Pxa=!0)}constructor(a){this.fa=a}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/59642624d5b2cea9.js.map