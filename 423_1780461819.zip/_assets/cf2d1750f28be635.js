(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[14567],{

/***/ 198958:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(73030);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Tad=__webpack_require__(296713),J6=Tad.jsx,Uad=Tad.jsxs;var Vad=__webpack_require__(270531).PA;var Wad=__webpack_require__(978109).useState;__c.jIc={jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-7",name:__c.Gb("vAIjvQ",[7])},C:__c.Mz(Vad(({data:{C:a},Zd:b})=>{const [c,d]=Wad("default");return Uad("div",{className:"aUnOsw",onMouseEnter:()=>d("hover"),onMouseLeave:()=>d("default"),onMouseDown:()=>d("pressed"),onMouseUp:()=>d("default"),children:[J6("div",{className:"jb1XWw",style:{border:`solid ${a.Kd}px  ${a.borderColor}`,borderRadius:`${a.V}px`},children:J6(b.kh,{fill:c==="pressed"?a.V2a:c==="hover"?a.U2a:a.S2a})}),J6("div",{className:"ziuV1Q",
children:J6("div",{children:J6(b.$i,{text:__c.Qi.create({...__c.wE,stream:__c.Yg(__c.yh.sb().attrs({"text-align":"center",color:a.W2a,"font-weight":"bold","font-size":16}).jb(a.title)).build()})})})})]})}))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/cf2d1750f28be635.js.map