(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[27212],{

/***/ 503451:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.JVb={config:{language:"en-PH",Mg:{yMMMd:"MMM d, yyyy",yMd:"M/d/yyyy",yMMM:"MMM yyyy"},fh:"Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),gh:"January February March April May June July August September October November December".split(" "),Zh:[{pattern:"mm *[/-] *dd *[/-] *yy",ya:"yMd"},{pattern:"mm *[/-] *dd *[/-] *yyyy",ya:"yMd"},{pattern:"mm *[/-] *dd",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/a4e9ba7ecd8f7056.js.map