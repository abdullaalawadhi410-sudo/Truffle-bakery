(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[82208],{

/***/ 697867:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(73030);__web_req__(143712);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.kIc={jk:__c.Nz()(({Rz:{expr:a}})=>({...__c.tV,metadata:{type:"demo-8",name:__c.Gb("vAIjvQ",[8])},C:{type:0,Fs:({C:b},{L:c})=>{const d=a.classes.q2,e=a.classes.s2,f=a.classes.GV,g=a.classes.RP,h=b.Mn,k=()=>c.I-12,l=()=>(h.size??12)*.67*((h.lineHeight??1400)/1E3),m=a.classes.o2.create({},{S:{fill:f.create({},{attributes:{color:()=>b.color}})},attributes:{top:0,left:0,width:()=>c.I,height:()=>c.O-4}}),n=d.create({},{S:{hb:a.list([()=>g.create({d:`M0 0 ${.05*c.I} ${4}C${.25*c.I} 0 ${.75*c.I} 0 ${.95*
c.I} ${4}l${.05*c.I}-${4}H0`},{S:{fill:f.create({},{attributes:{color:"#394c60",pa:.9}})},attributes:{}})])},attributes:{top:()=>c.O-4,left:0,width:()=>c.I,height:4,viewBox:()=>({top:0,left:0,width:c.I,height:4})}}),p=e.create({},{S:{text:()=>__c.yZ(b.text,{...__c.zZ(h),color:b.pd})},attributes:{left:6,top:6,width:k,height:()=>c.O-4-12-6-l(),dg:1}}),q=e.create({},{S:{text:()=>__c.yZ(b.tna,{...__c.zZ(h),color:b.pd,"text-align":"start","font-size":(h.size??12)*.67,"font-weight":"thin"})},attributes:{left:6,
top:()=>c.O-4-12+6-l(),width:k,height:l,dg:1}});return{Pa:a.list(()=>[n,m,p,q])}}}}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/5226b348008da156.js.map