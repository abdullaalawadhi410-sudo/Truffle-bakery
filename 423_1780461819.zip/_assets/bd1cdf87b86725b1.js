(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[24590],{

/***/ 604768:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Oxc=__webpack_require__(296713).jsx;var Pxc=__webpack_require__(978109),Qxc=Pxc.useLayoutEffect,Rxc=Pxc.useRef;var Sxc=__webpack_require__(186901).fm;__c.Txc=a=>{const b=({children:c})=>{const d=Rxc(null);Qxc(()=>Sxc(()=>{const {vertical:e,Ab:f}=a(),g=d.current;g&&g.setAttribute("transform",`scale(${e}, ${f})`)}),[]);return Oxc("g",{ref:d,children:c})};b.displayName=a.name!=null?`ScaledLayout(${a.name})`:"ScaledLayout";return b};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/bd1cdf87b86725b1.js.map