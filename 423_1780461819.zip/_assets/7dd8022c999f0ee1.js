(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[95184],{

/***/ 108353:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(73030);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var pad=__webpack_require__(296713),z6=pad.jsx,qad=pad.jsxs;var rad=__webpack_require__(270531).PA;__c.pIc={zCa:{c$b:"drop_fill"},jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-13",name:__c.Gb("vAIjvQ",[13])},C:__c.Mz(rad(({data:{C:a},Zd:b})=>qad("div",{className:"MG3Teg",children:[qad("div",{className:"WMGrpA",children:[z6("div",{children:"Droppable Fill"}),z6("div",{className:"AwHNDQ",children:z6(b.KV,{fill:a.u7a,bB:"drop_fill"})})]}),qad("div",{className:"WMGrpA",children:[z6("div",{children:"Non Droppable Fill"}),z6("div",{className:"AwHNDQ",children:z6(b.kh,{fill:a.gqb})})]})]})))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7dd8022c999f0ee1.js.map