(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[17710],{

/***/ 974581:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(734120);__web_req__(73030);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var c2=__c.c2;
var Cad=function(){var a=__c.vNc(__c.wNc([A6("C"),A6("D")]),B6(Math.sqrt(2)));var b={top:__c.vNc(__c.uNc(A6("D"),A6("d")),B6(2)),left:__c.vNc(__c.uNc(A6("C"),A6("d")),B6(2)),width:A6("d"),height:A6("d"),rotation:B6(45),V:c2([B6(10)]),fill:C6("Fill",{color:A6("A")}),stroke:Bad({color:A6("B"),weight:B6(5),Qc:c2([]),hf:B6(!0)})};a={kind:10,defs:new Map([["d",a]]),body:C6("RectElement",{...b,rotation:b.rotation??B6(),stroke:b.stroke??B6(),V:b.V??B6()})};b={d:B6("M17.5 2.5C9.125 2.5 2.5 9.25 2.5 17.5c0 16.875 17 21.25 28.5 37.875 11-16.5 28.625-21.625 28.625-37.875 0-8.25-6.75-15-15-15-6 0-11.25 3.5-13.625 8.625-2.375-5.125-7.5-8.625-13.5-8.625z"),stroke:Bad({color:A6("B"),
weight:B6(5),hf:B6(!0),Qc:c2([])}),fill:C6("Fill",{color:B6("#ff3b4b")})};b={hb:c2([C6("Path",{...b,stroke:b.stroke??B6()})]),top:B6(28),left:B6(19),width:B6(62),height:B6(60),viewBox:{kind:6,fields:{top:B6(0),left:B6(0),width:B6(62),height:B6(60)}}};return{kind:0,qea:[],body:c2([a,C6("ShapeElement",{...b,rotation:b.rotation??B6(),pa:b.pa??B6()})])}},B6=function(a){return{kind:1,value:a}},C6=function(a,b){return{kind:7,name:a,args:b}},A6=function(a){return{kind:9,name:a}},Bad=function(a){return C6("Stroke",
a)};__c.eIc={jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-2",name:()=>__c.Gb("vAIjvQ",[2])},fR:["responsive"],C:{type:0,Fs:Cad()}}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/2f0f089ee94dbcaa.js.map