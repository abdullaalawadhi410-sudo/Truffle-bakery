(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[52693],{

/***/ 255670:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.MVb={config:{language:"es-ES",Mg:{yMMMd:"d MMM yyyy",yMd:"d/M/yyyy",yMMM:"MMM yyyy"},fh:"ene feb mar abr may jun jul ago sept oct nov dic".split(" "),gh:"enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre".split(" "),Zh:[{pattern:"dd *[/-] *mm *[/-] *yy",ya:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",ya:"yMd"},{pattern:"dd *[/-] *mm",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/ca30234ebb4f421a.js.map