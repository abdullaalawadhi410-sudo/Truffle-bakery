(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[82433],{

/***/ 537257:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(940814);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var HCc=__webpack_require__(296713).jsx;__webpack_require__(978109);var ICc;ICc=a=>HCc(__c.p_,{buttons:[{className:"BB6Tuw"}],DR:a.description,open:!0,title:a.title});__c.kca={cvb:()=>{var a=__c.K("guY7ag"),b=__c.K("eUGHYg");return HCc(ICc,{title:a,description:b})},rvb:()=>HCc(ICc,{title:__c.K("guY7ag"),description:__c.K("idpShQ")}),tac:ICc};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c95ff6e5dbf78cf9.js.map