(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[10468],{

/***/ 334167:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(73030);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.gIc={jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-4",name:__c.Gb("vAIjvQ",[4])},C:__c.Mz(()=>{throw Error("Demo error");})}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/8d3e33ac7d7f61a7.js.map