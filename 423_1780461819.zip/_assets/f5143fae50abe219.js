(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[51053],{

/***/ 863262:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.YVb={config:{language:"nl-NL",Mg:{yMMMd:"d MMM yyyy",yMd:"d-M-yyyy",yMMM:"MMM yyyy"},fh:"jan feb mrt apr mei jun jul aug sep okt nov dec".split(" "),gh:"januari februari maart april mei juni juli augustus september oktober november december".split(" "),Zh:[{pattern:"yyyy *[./-] *mm *[./-] *dd",ya:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yy",ya:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",ya:"yMd"},{pattern:"dd *[./-] *mm",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/f5143fae50abe219.js.map