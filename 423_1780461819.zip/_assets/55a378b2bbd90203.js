(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[897],{

/***/ 645980:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(530338);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.Cvc=function(a,b){return b?__c.MX(a.color_by,0).TD:__c.PY(a)};__c.TY=function(a,b,c){a=a.rows.flatMap(d=>d.value_by.jf(e=>b(e)));if(!a.length)return __c.MY;c=__c.xvc({...c,ycb:!1,data:a});return c[0].value===c[1].value?__c.MY:c};__c.UY=function(a,b,c){return a.rows.map((d,e)=>{d=d[b].get(0);d=d!=null?c(d):"";return`${e}.${d}`})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/55a378b2bbd90203.js.map