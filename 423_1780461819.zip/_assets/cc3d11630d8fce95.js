(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[87689],{

/***/ 730038:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.RVb={config:{language:"fr-CA",Mg:{yMMMd:"d MMM yyyy",yMd:"yyyy-MM-dd",yMMM:"MMM yyyy"},fh:"janv. f\u00e9vr. mars avr. mai juin juill. ao\u00fbt sept. oct. nov. d\u00e9c.".split(" "),gh:"janvier f\u00e9vrier mars avril mai juin juillet ao\u00fbt septembre octobre novembre d\u00e9cembre".split(" "),Zh:[{pattern:"yyyy *[./-] *mm *[./-] *dd",ya:"yMd"},{pattern:"yy *[./-] *mm *[./-] *dd",ya:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",ya:"yMd"},{pattern:"mm *[./-] *dd",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/cc3d11630d8fce95.js.map