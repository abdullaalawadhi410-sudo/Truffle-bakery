(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[32671],{

/***/ 347520:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(685713);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var rQc,sQc;rQc=function(a,{status:b,endTime:c,ref:d,url:e,file:f,type:g,span:h}){({Ok:c}=h.end(b===0?"ok":"error",c));a.Hc.track(__c.bxc,{source:"editor",success:b===0,resourceId:d.id,resourceType:__c.I_b.serialize(g),version:d.version,url:e,height:f.height,width:f.width,quality:f.quality?__c.GU.serialize(f.quality):void 0,Nj:f.Nj,qg:f.qg,De:c()})};
sQc=class{static create({Hc:a,lb:b,c0b:c=.01,d0b:d=Math.random}){if(!(c<d()))return new sQc(a,b)}eka({ref:a,file:b,type:c,startTime:d}){const e=b.url.startsWith("data:image/")?void 0:b.url,f=this.lb.kj("load_image",{startTime:d,attrs:new Map([["id",a.id],["version",a.version],["url",e],["height",b.height],["width",b.width],["quality",b.quality],["watermarked",b.Nj],["spritesheet",b.qg]])});return{end:(g,h)=>rQc(this,{status:g,endTime:h,ref:a,url:e,file:b,type:c,span:f})}}constructor(a,b){this.Hc=
a;this.lb=b}};__c.$va={};__c.$va.oxb=sQc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/40f4e3dc5575816e.js.map