(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[15670],{

/***/ 916457:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var rUc=__webpack_require__(978109).createRef;var sUc=__webpack_require__(186901),tUc=sUc.EW,d3=sUc.sH;var uUc;
uUc=class{static G(a){__c.M(a,{y8:d3.ref,lDa:d3.ref,enabled:tUc,open:tUc,key:d3.ref,DH:d3.ref,position:tUc,content:d3.ref,placement:d3.ref,arrow:d3.ref})}get enabled(){return!this.D.bi.RU.disabled}get open(){return this.lDa&&this.enabled&&this.ELb()}set open(a){this.lDa=a}set position(a){this.DH=a}get position(){const a=this.DH,b=this.D.padding,c=this.ga?.get()??1;return{left:c*((this.sh?a.left-this.D.width:a.left)+b.left),top:c*(a.top+b.top),width:c*a.width,height:c*a.height}}constructor(a,b,c,d=
__c.Jc.direction===2){this.D=a;this.ga=b;this.ELb=c;this.sh=d;this.y8=(uUc.G(this),rUc());this.lDa=!1;this.key=void 0;this.DH={top:0,left:0,width:0,height:0};this.content="";this.placement="bottom-center";this.arrow=!0;this.He=0}};__c.Jz={};__c.Jz.LZa=uUc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b04eaca137ed8cab.js.map