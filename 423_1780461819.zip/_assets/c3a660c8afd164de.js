(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[17067],{

/***/ 592660:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.TVb={config:{language:"id-ID",Mg:{yMMMd:"d MMM yyyy",yMd:"d/M/yyyy",yMMM:"MMM yyyy"},fh:"Jan Feb Mar Apr Mei Jun Jul Agu Sep Okt Nov Des".split(" "),gh:"Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember".split(" "),Zh:[{pattern:"yyyy *[./-] *mm *[./-] *dd",ya:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yy",ya:"yMd"},{pattern:"dd *[./-] *mm *[./-] *yyyy",ya:"yMd"},{pattern:"dd *[./-] *mm",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c3a660c8afd164de.js.map