(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[92465],{

/***/ 143712:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Uxc;__c.yZ=function(a,b={}){a=a.endsWith("\n")?a:a+"\n";return __c.Qi.create({...__c.wE,stream:__c.yh.sb().attrs({"font-size":4,...b}).jb(a).build()})};Uxc=a=>{switch(a){case "bulleted":return{"list-marker":"disc","list-level":1,"head-indent":1700};case "numbered":return{"list-marker":"decimal","list-level":1,"head-indent":1700};case "checked":case "unchecked":case "none":return{"list-marker":"none","list-level":0,"head-indent":0};case void 0:return{};default:throw new __c.z(a);}};
__c.zZ=a=>({decoration:a.Ke,direction:a.direction,"font-family":a.fontFamily,"font-style":a.fontStyle,"font-weight":a.fontWeight,tracking:a.letterSpacing,leading:a.lineHeight,...Uxc(a.gj),"font-size":a.size,strikethrough:a.Dk,"text-align":a.textAlign,"text-transform":a.textTransform});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c7506060ea8d4dfc.js.map