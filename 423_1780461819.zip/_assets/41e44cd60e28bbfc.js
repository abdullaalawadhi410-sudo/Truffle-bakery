(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[2645],{

/***/ 930655:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Irc=__webpack_require__(894175).eU;__c.oca={render:function(a){try{globalThis.__app_server_page_callback__(void 0,{app:a,renderToPipeableStream:Irc})}catch(b){globalThis.__app_server_page_callback__(b,{app:a,renderToPipeableStream:Irc})}}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/41e44cd60e28bbfc.js.map