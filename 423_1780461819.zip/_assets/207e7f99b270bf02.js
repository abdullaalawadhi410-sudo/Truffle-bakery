(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[79878],{

/***/ 948377:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var pVc=function(a,{EC:b,II:c,sY:d}){a.osb.push(b);a.Kjb.push(c);a.sY=d},qVc=class{a3a(a){a=a.config;const b=this.sY?.(a.ref);var c;if(c=b)a:{if(__c.KG.has(a.ref.type))for(var d of b.filters)if(b.Px(d).isDirty){c=!0;break a}c=!1}if(c)return d=this.EC(a.ref),a=this.II(a.ref),{top:d.top-a.top,left:d.left-a.left,bottom:d.bottom-a.bottom,right:d.right-a.right}}EC(a){for(const b of this.osb){const c=b(a);if(c)return c}return __c.lz}II(a){for(const b of this.Kjb){const c=b(a);if(c)return c}return __c.lz}constructor(){this.osb=
[];this.Kjb=[];this.sY=void 0}};var j3;__c.cIa={COb:function({EC:a,II:b,sY:c}){if(j3)return pVc(j3,{EC:a,II:b,sY:c}),j3;const d=new qVc;pVc(d,{EC:a,II:b,sY:c});return j3=d}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/207e7f99b270bf02.js.map