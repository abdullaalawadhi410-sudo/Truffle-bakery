(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[86533],{

/***/ 729702:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.aWb={config:{language:"pt-PT",Mg:{yMMMd:'d "de" MMM "de" yyyy',yMd:"dd/MM/yyyy",yMMM:'MMM "de" yyyy'},fh:"jan. fev. mar. abr. mai. jun. jul. ago. set. out. nov. dez.".split(" "),gh:"janeiro fevereiro mar\u00e7o abril maio junho julho agosto setembro outubro novembro dezembro".split(" "),Zh:[{pattern:"dd *[./\\s-] *mm *[./\\s-] *yy",ya:"yMd"},{pattern:"dd *[./\\s-] *mm *[./\\s-] *yyyy",ya:"yMd"},{pattern:"yyyy *[./\\s-] *mm *[./\\s-] *dd",ya:"yMd"},{pattern:"dd *[./\\s-] *mm",ya:"yMd"},{pattern:"mmm de yyyy",
ya:"yMMM"},{pattern:"dd de mmm de yyyy",ya:"yMMMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/2bf91389fbf307e8.js.map