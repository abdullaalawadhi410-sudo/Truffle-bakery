(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[72397],{

/***/ 978890:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var k_=Math.PI/5,l_=Math.cos(k_),m_=Math.sin(k_),RAc=Math.cos(k_/2),SAc=Math.sin(k_/2),TAc=Math.atan(Math.PI/2-2*k_);__c.UAc={[1]:function({x:a,y:b},c){const d=c/2;return["M",a+d,b,"a",d,d,0,0,0,-c,0,"a",d,d,0,0,0,c,0,"Z"].join(" ")},[2]:function({x:a,y:b},c,d){c/=2;d=d||0;return["M",a+c,b+c-d,"L",a+c,b-c+d,"A",d,d,0,0,0,a+c-d,b-c,"L",a-c+d,b-c,"A",d,d,0,0,0,a-c,b-c+d,"L",a-c,b+c-d,"A",d,d,0,0,0,a-c+d,b+c,"L",a+c-d,b+c,"A",d,d,0,0,0,a+c,b+c-d,"Z"].join(" ")},[3]:function({x:a,y:b},c){c/=2;return["M",a,b+c,"L",a+c,b,"L",a,b-c,"L",a-c,b,"Z"].join(" ")},[4]:function({x:a,y:b},c){c/=2;return["M",a,b-c,"L",a-c,b+c,"L",
a+c,b+c,"Z"].join(" ")},[5]:function({x:a,y:b},c){c/=2;const d=2*c*m_,e=c-d*m_,f=d*l_,g=Math.sqrt(e*e+Math.pow(TAc*d*m_,2));return["M",a,b-c,"L",a-m_*g,b-l_*g,"L",a-f,b-e,"L",a-RAc*g,b+SAc*g,"L",a-d/2,b+c*l_,"L",a,b+g,"L",a+d/2,b+c*l_,"L",a+RAc*g,b+SAc*g,"L",a+f,b-e,"L",a+m_*g,b-l_*g,"Z"].join(" ")}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c767591e543c7e32.js.map