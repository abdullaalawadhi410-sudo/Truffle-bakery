(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[66795],{

/***/ 139668:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {__c.UVb={config:{language:"it-IT",Mg:{yMMMd:"d MMM yyyy",yMd:"dd/MM/yyyy",yMMM:"MMM yyyy"},fh:"gen feb mar apr mag giu lug ago set ott nov dic".split(" "),gh:"gennaio febbraio marzo aprile maggio giugno luglio agosto settembre ottobre novembre dicembre".split(" "),Zh:[{pattern:"dd *[/-] *mm *[/-] *yy",ya:"yMd"},{pattern:"dd *[/-] *mm *[/-] *yyyy",ya:"yMd"},{pattern:"dd *[/-] *mm",ya:"yMd"}]}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/e4152cdfc66dc042.js.map