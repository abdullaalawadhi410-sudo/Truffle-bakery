(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[97668],{

/***/ 634217:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Hxc=__webpack_require__(186901).EW;__c.xZ=class{static G(a){__c.M(a,{step:Hxc})}get kind(){return"point"}clone({kc:a=this.kc,wc:b=this.wc,Pi:c=this.Pi,bf:d=this.bf,inverse:e=this.inverse}){return new __c.xZ({kc:a,wc:b,Pi:c,bf:d,inverse:e})}snapshot(){const a=this.kc(),b=this.wc();return new __c.xZ({kc:()=>a,wc:()=>b,Pi:this.Pi,bf:this.bf,inverse:this.inverse})}get(a){const b=this.kc();var c=b.indexOf(a);c=this.inverse?b.length-1-c:c;__c.w(c!==-1,`value ${a} must exist in domain`);const [d,e]=this.wc();a=b.length===1?.5:this.Pi();return d+
(a*this.step+c*this.step)*Math.sign(e-d)}get step(){const a=this.kc().length+2*this.Pi(),[b,c]=this.wc();return Math.abs(c-b)/Math.max(a-1,1)}TW(a,b,c){__c.w(a.index!==b.index);const d=this.Pi(),e=(b.center-a.center)/(b.index-a.index);return[a.center-(d+a.index)*e,b.center+(d+c-b.index-1)*e]}SW(a,b,c){const d=this.Pi();return[b,a.center+(a.center-b)/(a.index+d)*(d+c-a.index-1)]}RW(a,b,c){const d=this.Pi();return[a.center-(b-a.center)/(c-a.index-1+d)*(d+a.index),b]}constructor({kc:a,wc:b,Pi:c,bf:d,
inverse:e=!1}){__c.xZ.G(this);this.kc=a;this.wc=b;this.Pi=c;this.bf=d;this.inverse=e}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/7223576b8edd06a1.js.map