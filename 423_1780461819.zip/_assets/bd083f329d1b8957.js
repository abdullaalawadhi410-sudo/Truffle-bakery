(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[96145],{

/***/ 260070:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Gkd=__webpack_require__(186901).O8;var Ikd,Hkd;
Ikd=class{get Fe(){if(this.xG){this.xG&&(this.kd.now()>this.xG.pdb+18E5&&(this.xG.id=__c.ks()),this.xG.pdb=this.kd.now());var a=this.xG.mx,b=this.xG.ih,c=this.xG.OZ,d=b.Lb,e=this.xG.ih.Gc.VR(d);return{xg:"DAAAAAAAA1",fd:void 0,mode:c.mode,mx:Hkd[a],xYb:this.xG.id,XPa:b.Wr,xUb:b.Fa.X.count(),Af:b.kf,location:this.location,$ib:b.Gc.cLb(d),bjb:e==="inline"?"custom":e?.id,tp:d.id}}}track(a,b){this.dAb.track(a,{...b,Fe:Gkd(()=>this.Fe)})}UNb(a){this.xG={id:__c.ks(),pdb:this.kd.now(),...a};return()=>this.xG=
void 0}constructor(a,b,c=__c.eu){this.dAb=a;this.location=b;this.kd=c}};Hkd={[2]:"viewer",[3]:"viewer",[4]:"investigator",[5]:"commenter",[6]:"editor",[7]:"contentManager",[8]:"admin",[9]:"owner",[1]:void 0};__c.j3a={};__c.j3a.dxb=Ikd;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/bd083f329d1b8957.js.map