(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[4689],{

/***/ 644902:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var Uuc,Tuc;__c.Suc=function(a,b){return __c.Qi.create({...__c.wE,stream:__c.yh.sb().attrs({"font-size":a.fontSize,"font-weight":a.fontWeight,"font-style":a.fontStyle,"font-family":a.Yq}).jb(`${b}\n`).build()})};
Uuc=class{aHa(a,b){const c=a.stream.Wj(0),{fontSize:d,fontFamily:e,fontWeight:f,fontStyle:g}={fontSize:c["font-size"]??__c.bg.uc["font-size"],fontFamily:c["font-family"]||__c.bg.uc["font-family"],fontWeight:c["font-weight"]||__c.bg.uc["font-weight"],fontStyle:c["font-style"]||__c.bg.uc["font-style"]};return`${a.stream.ea.substring(0,a.stream.charLength-1)}.${d.toFixed(1)}.${e}.${__c.Cs(f)}.${g}.${b.toFixed(1)}`}J7(a,b){if(a.stream.charLength===1||b===0)var c=[];else{{c=this.cache;const d=c.aHa(a,
b),e=c.cache.get(d);e!=null?c=e:(a=c.J7(a,b),c.cache.set(d,a),c=a)}}return c}constructor(a){this.tg=a;this.cache=new Tuc((b,c)=>{if(b.stream.charLength===1||c===0)var d=[];else{b=__c.Iu(this.tg,b.an(this.Hd),1,"em-square");try{d=b.J7(c)}finally{b.destroy()}}return d},(b,c)=>this.aHa(b,c));this.Hd={styles:new Map,version:0}}};Tuc=class{constructor(a,b){this.J7=a;this.aHa=b;this.cache=new Map}};__c.Lz={};__c.Lz.KZa=Uuc;__c.Lz.cwc=__c.Suc;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/5989cd97b908b258.js.map