(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[77253],{

/***/ 245116:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(385418);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var N4c=function(a,b){var c=a.Rp.Zr,d=a.Rp.yqa,e=c.jpa;const f=c.qpa;c=d.jpa;d=d.qpa;a=__c.iv(a,b);switch(b.type){case "fixed-page":case "concatenated-fixed-page":(e=e?.(a,b))&&c&&(e=c(e,b));break;case "responsive-page":(e=f?.(a,b))&&d&&(e=d(e,b));break;default:e=a}return e},O4c=__webpack_require__(296713).jsx;var P4c=__webpack_require__(270531).PA;__webpack_require__(978109);var Q4c;Q4c=P4c(({rj:a})=>O4c("div",{id:a.id,role:a.role,"aria-label":a.name??__c.K("ITH8Bg")}));__c.Eic={avb:P4c(({page:a,controller:b,config:c,...d})=>{c=c.wd;switch(a.type){case "fixed-page":return(b=N4c(b,a))&&O4c(c,{page:a,rj:b,...d});default:return(d=N4c(b,a))&&O4c(Q4c,{page:a,rj:d})}})};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/b4cfa4fbddbacbe3.js.map