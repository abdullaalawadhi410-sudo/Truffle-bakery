(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[39028],{

/***/ 220309:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var zzc;__c.XZ=function(a,b=1){return zzc(()=>!__c.My()&&a.reduce((c,d)=>d.get().length+c,0)<150/b)};zzc=__webpack_require__(186901).EW;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/47c12f1f44ca2b0d.js.map