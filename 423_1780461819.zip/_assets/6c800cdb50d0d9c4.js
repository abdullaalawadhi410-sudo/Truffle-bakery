(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[98259],{

/***/ 309378:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(73030);__web_req__(143712);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var had=__webpack_require__(296713).jsx;var iad=__webpack_require__(270531).PA;__c.mIc={jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-10",name:__c.Gb("vAIjvQ",[10])},C:__c.Mz(iad(({data:{document:a,C:b},Zd:c,Da:{page:d}})=>{c=c.$i;var e=__c.Qi.create;b=__c.yh.sb().attrs({...__c.zZ(a.Mn),color:b.pd??a.pd});var f=b.jb;a=a.gbb;const g=(d.WR()+1).toString();return had("div",{className:"LjWkdQ",children:had(c,{text:e.call(__c.Qi,{...__c.wE,stream:__c.Yg(f.call(b,a?d.title?`Page ${g}:\n${d.title}`:`Page ${g}`:g)).build()})})})}))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/6c800cdb50d0d9c4.js.map