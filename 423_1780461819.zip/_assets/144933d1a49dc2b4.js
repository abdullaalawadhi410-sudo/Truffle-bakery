(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[58095],{

/***/ 730022:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var wGd=__webpack_require__(296713).jsx;var xGd=__webpack_require__(978109).memo;__c.Nmc={cHa:function({Hk:a}){return xGd(function({height:b,page:c,width:d,fit:e}){return wGd("div",{style:{width:d,height:b},children:wGd(a,{page:c,Qb:d,qc:b,fit:e,Yc:!1,Rf:__c.XV})})})}};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/144933d1a49dc2b4.js.map