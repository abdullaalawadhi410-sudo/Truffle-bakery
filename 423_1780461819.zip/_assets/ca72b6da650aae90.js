(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[40797],{

/***/ 470496:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(734120);__web_req__(73030);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var wad=__webpack_require__(296713),xad=wad.jsx,yad=wad.jsxs;var zad=__webpack_require__(270531).PA;__webpack_require__(978109);var Aad;Aad=zad(function({Zd:a,id:b,rect:c}){return xad(a.Un,{bB:b,Hg:{left:c.left,top:c.top,width:c.width,height:c.height,rotation:c.rotation},style:{backgroundColor:c.color,borderRadius:4,cursor:"pointer"}})});
__c.sIc={jk:__c.Nz()(()=>({...__c.tV,metadata:{type:"demo-16",name:__c.Gb("vAIjvQ",[16])},fR:["responsive"],C:__c.Mz(zad(({Da:{Pb:a},Zd:b,data:{C:c}})=>yad("div",{style:{position:"relative",width:"100%",height:"100%"},children:[c.rects.map((d,e)=>xad(Aad,{Zd:b,id:`rect-${e}`,rect:d},e)),a<=10&&xad("div",{style:{position:"absolute",top:0,left:0,right:0,bottom:0,display:"flex",alignItems:"center",justifyContent:"center",color:"#666",fontSize:8,pointerEvents:"none"},children:"Demo 16: Movable Rects"})]})))}))};
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/ca72b6da650aae90.js.map