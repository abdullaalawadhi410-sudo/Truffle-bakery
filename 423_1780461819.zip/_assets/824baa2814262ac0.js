(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[36931],{

/***/ 540764:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(685713);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var R8c,U8c,T8c,S8c;R8c=function(a,{success:b,endTime:c,fill:d,file:e,url:f,X0b:g,span:h}){({Ok:c}=h.end(b?"ok":"error",c));a.Hc.track(__c.bxc,{source:"editor",success:b,resourceId:d.video,resourceType:g,url:f,height:e.height,width:e.width,quality:e.quality,Nj:e.Nj,De:c()})};
U8c=class{r3b({fill:a,startTime:b,file:c}){if(!this.dBa.has(a)&&!this.Orb.has(a)){var d=c.url?.startsWith("data:")||c.url?.startsWith("blob:")?void 0:c.url,e=c.container&&S8c(c.container),f=this.lb.kj("load_video",{startTime:b,attrs:new Map([["id",a.video],["url",T8c(d)],["height",c.height],["width",c.width],["quality",c.quality],["container",e],["watermarked",c.Nj]])});this.dBa.set(a,{end:(g,h)=>R8c(this,{success:g,endTime:h,fill:a,file:c,url:d,X0b:e,span:f})})}}l8a({success:a,fill:b,endTime:c}){const d=
this.dBa.get(b);d&&(d.end(a,c),this.dBa.delete(b),this.Orb.add(b))}constructor(a,b){this.Hc=a;this.lb=b;this.dBa=new WeakMap;this.Orb=new WeakSet}};T8c=a=>{if(!a)return a;let b;try{b=new URL(a)}catch(c){return a}b.search="";return b.toString()};S8c=a=>{switch(a){case 1:return"MP4";case 2:return"GIF";case 4:return"LOTTIE";case 3:return"WEBM";default:throw new __c.z(a);}};__c.pVa={};__c.pVa.Lxb=U8c;
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/824baa2814262ac0.js.map