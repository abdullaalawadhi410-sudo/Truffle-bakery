(globalThis["webpackChunk_canva_web"] = globalThis["webpackChunk_canva_web"] || []).push([[59352],{

/***/ 45331:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(905716);__web_req__(200636);globalThis._5f74ec40302898c5a55451c9fbd04240 = globalThis._5f74ec40302898c5a55451c9fbd04240 || {};(function(__c) {var bwc=__webpack_require__(296713),cwc=bwc.jsx,dwc=bwc.jsxs;__c.jZ=(0,__webpack_require__(978109).memo)(({header:a,body:b})=>dwc("div",{children:[a!=null?cwc(__c.Tw,{weight:"bold",size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:a}):void 0,b.map((c,d)=>cwc(__c.Tw,{size:"small",tagName:"div",lineClamp:0,tone:"primary",className:"_2V1T4g",alignment:"center",children:c},d))]}));__c.kZ=()=>({x:{get:a=>a.za.title,direction:"horizontal",float:"bottom"},y:{get:a=>a.va.title,direction:"vertical",float:"left"}});
}).call(globalThis, globalThis._5f74ec40302898c5a55451c9fbd04240);}

}])
//# sourceMappingURL=sourcemaps/c669cef341f1ed02.js.map